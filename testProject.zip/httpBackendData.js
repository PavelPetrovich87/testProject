/*
    {
  "acl": [
    {
      "users": [],
      "name": "LNP",
      "key": "lnp",
      "description": null,
      "id": 1,
      "modifiedOn": "2016-04-27T15:47:59.000Z"
    },
    {
      "users": [],
      "name": "DID",
      "key": "did",
      "description": null,
      "id": 2,
      "modifiedOn": "2016-04-27T15:47:59.000Z"
    }
  ],
  "login": "1000@unitedcloud",
  "email": null,
  "username": "",
  "prefix": "unitedc_",
  "scope": {
    "name": "Reseller",
    "key": "reseller",
    "id": 3
  },
  "active": 1,
  "id": 4,
  "modifiedOn": "2016-06-12T15:09:42.000Z",
  "createdOn": "2016-04-28T14:41:28.000Z",
  "jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2wiOlt7InVzZXJzIjpbXSwibmFtZSI6IkxOUCIsImtleSI6ImxucCIsImRlc2NyaXB0aW9uIjpudWxsLCJpZCI6MSwibW9kaWZpZWRPbiI6IjIwMTYtMDQtMjdUMTU6NDc6NTkuMDAwWiJ9LHsidXNlcnMiOltdLCJuYW1lIjoiRElEIiwia2V5IjoiZGlkIiwiZGVzY3JpcHRpb24iOm51bGwsImlkIjoyLCJtb2RpZmllZE9uIjoiMjAxNi0wNC0yN1QxNTo0Nzo1OS4wMDBaIn1dLCJsb2dpbiI6IjEwMDBAdW5pdGVkY2xvdWQiLCJlbWFpbCI6bnVsbCwidXNlcm5hbWUiOiIiLCJwcmVmaXgiOiJ1bml0ZWRjXyIsInNjb3BlIjp7Im5hbWUiOiJSZXNlbGxlciIsImtleSI6InJlc2VsbGVyIiwiaWQiOjN9LCJhY3RpdmUiOjEsImlkIjo0LCJtb2RpZmllZE9uIjoiMjAxNi0wNi0xMlQxNTowOTo0Mi4wMDBaIiwiY3JlYXRlZE9uIjoiMjAxNi0wNC0yOFQxNDo0MToyOC4wMDBaIiwiaWF0IjoxNDY1OTA5OTcxfQ.50YXVv44aZDdkdXlheYbBHK5NMatVzBgkju0jDa26C8"
}
*/