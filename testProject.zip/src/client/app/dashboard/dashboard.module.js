(function() {
  'use strict';

  angular.module('app.dashboard', [
    'app.core',
    'app.widgets',
  ]);
})();
