(function() {
  'use strict';

  angular.module('app', [
    'app.core',
    'app.widgets',
    'app.admin',
    'app.dashboard',
    'app.lnp',
    'app.login',
    'app.layout',
    'core.auth'
  ]);
})();
