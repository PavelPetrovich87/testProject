(function() {
  'use strict';

  angular.module('blocks.router', [
    'ui.router',
    'core.logger',
    'core.auth'
  ]);
    
})();
