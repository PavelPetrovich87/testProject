(function() {
  'use strict';

  angular.module('blocks.exception', ['core.logger']);
})();
