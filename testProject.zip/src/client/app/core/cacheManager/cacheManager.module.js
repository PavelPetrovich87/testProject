(function(){
    'use strict';

    angular.module('core.cacheManager', ['core.logger', 'ngStorage']);

})()