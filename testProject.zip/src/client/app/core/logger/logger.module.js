(function() {
  'use strict';

  angular.module('core.logger', []);
})();
