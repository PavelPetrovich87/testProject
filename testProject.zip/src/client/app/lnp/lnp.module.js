(function(){
    'use strict';

    angular.module('app.lnp', ['app.core']);
})()